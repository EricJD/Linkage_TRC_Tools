package de.uni_leipzig.asv.toolbox.ChineseWhispers;

// standard imports
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.Icon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;

import de.uni_leipzig.asv.toolbox.ChineseWhispers.main.Start;
import de.uni_leipzig.asv.toolbox.toolboxGui.Toolbox;
import de.uni_leipzig.asv.toolbox.toolboxGui.ToolboxModule;

public class WTool extends ToolboxModule {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	JTabbedPane jTabbedPane1 = null;

	TitledBorder titledBorder1;

	Frame parentFrame = null;

	public WTool(Toolbox wTool) {
		super(wTool);
		// set display mode
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			SwingUtilities.updateComponentTreeUI(this);
			UIManager.getLookAndFeelDefaults().put("Label.font",
					new Font(null, Font.ROMAN_BASELINE, 11));
			UIManager.getLookAndFeelDefaults().put("RadioButton.font",
					new Font(null, Font.ROMAN_BASELINE, 11));
			UIManager.getLookAndFeelDefaults().put("TextField.font",
					new Font(null, Font.ROMAN_BASELINE, 11));
			UIManager.getLookAndFeelDefaults().put("Button.font",
					new Font(null, Font.BOLD, 11));
			UIManager.getLookAndFeelDefaults().put("CheckBox.font",
					new Font(null, Font.ROMAN_BASELINE, 11));
		} catch (Exception e2) {
			System.out.println("Error in GUI");
		}
		this.parentFrame = wTool.getParentFrame();
		this.jTabbedPane1 = (new Start()).getTabbedPane();
		// this.jTabbedPane1.setBackground(this.parentFrame.getBackground());

		try {
			jbInit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void jbInit() throws Exception {
		this.titledBorder1 = new TitledBorder("");

		this.jTabbedPane1.setDoubleBuffered(true);
		this.jTabbedPane1.setBounds(ToolboxModule.moduleBounds);
		this.add(this.jTabbedPane1, null);
	}

	@Override
	public void activated() {
		repaint();
	}

	@Override
	public JPanel getModulePanel() {
		return this;
	}

	@Override
	public char getMnemonic() {
		return 'C';
	}

	@Override
	public String getName() {
		return "Chinese Whispers";
	}

	@Override
	public Icon getIcon() {
		return createImageIcon("./img/whisper.jpg");
	}

	@Override
	public String getToolTip() {
		return "Calculates with Chinese Whispers algorithm.";
	}

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setSize(new Dimension(800, 600));
		WindowListener l = new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		};
		frame.addWindowListener(l);

		frame.setTitle("Wortschatz Tool");
		WTool wtool = new WTool(null);
		frame.getContentPane().add(wtool, null);
		frame.pack();
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setLocation(screenSize.width / 2 - frame.getSize().width / 2,
				screenSize.height / 2 - frame.getSize().height / 2);
		frame.show();
	}
}
